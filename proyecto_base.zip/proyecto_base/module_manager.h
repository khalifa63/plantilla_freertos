// ============================================================
// module_manager.h - Gestor de módulos plug-and-play
//
// CÓMO AGREGAR HARDWARE NUEVO (sin tocar ningún archivo existente):
//   1. Crear  mi_modulo.cpp  en la raíz del sketch
//   2. Implementar:  static bool miInit(void);
//                    static void miStart(void);
//   3. Al final del archivo:
//        REGISTER_MODULE("mi_modulo", miInit, miStart, 50, false);
//   4. Compilar. El .ino y los demás archivos NO se modifican.
//
// El registro ocurre ANTES de setup() mediante constructores de
// objetos estáticos (idioma "construct on first use" para evitar
// el problema de orden de inicialización estática).
//
// Parámetros de REGISTER_MODULE:
//   name     : nombre para logs por serial
//   initFn   : bool init(void)  -> true si el hardware respondió
//   startFn  : void start(void) -> lanza la(s) tarea(s) FreeRTOS
//   priority : 0-255, menor = se inicializa primero
//              (convención: 10=buses/criticos, 50=sensores,
//               100=salidas/UI, 200=opcionales)
//   critical : true  -> si init falla, el sistema entra en
//                       sysFatalError() y no continúa
//              false -> se loguea [WARN] y el resto sigue
// ============================================================
#ifndef MODULE_MANAGER_H
#define MODULE_MANAGER_H

#include <Arduino.h>

typedef bool (*ModuleInitFn)(void);
typedef void (*ModuleStartFn)(void);

struct ModuleDesc {
    const char    *name;
    ModuleInitFn   init;
    ModuleStartFn  start;
    uint8_t        priority;
    bool           critical;
};

// --- API usada por el .ino ---
// Inicializa todos los módulos en orden de prioridad.
// Devuelve false si falló el init de algún módulo CRÍTICO.
bool modulesInitAll(void);

// Lanza las tareas de todos los módulos cuyo init fue exitoso.
void modulesStartAll(void);

// --- Mecanismo de auto-registro (uso interno del macro) ---
bool moduleRegister(const ModuleDesc &desc);

class ModuleRegistrar {
public:
    ModuleRegistrar(const char *name, ModuleInitFn init, ModuleStartFn start,
                    uint8_t priority, bool critical) {
        ModuleDesc d = { name, init, start, priority, critical };
        moduleRegister(d);
    }
};

#define REGISTER_MODULE(name, initFn, startFn, priority, critical) \
    static ModuleRegistrar _modreg_##initFn(name, initFn, startFn, priority, critical)

#endif // MODULE_MANAGER_H
