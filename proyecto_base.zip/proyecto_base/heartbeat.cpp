// ============================================================
// heartbeat.cpp - Módulo autocontenido: LED de vida (GPIO2)
//
// PLUG-AND-PLAY: sin .h propio, estado static, auto-registro.
// Prueba de vida del scheduler aunque otros módulos fallen.
// ============================================================
#include "app_config.h"
#include "module_manager.h"

// ------------------------------------------------------------
// CONFIG DEL MÓDULO
// ------------------------------------------------------------
#define PIN_LED_HEARTBEAT    PIN_LED_SYS   // Comparte el LED de sistema
#define LED_BLINK_MS         250
#define TASK_BLINK_STACK     2048
#define TASK_BLINK_PRIO      1
#define TASK_BLINK_CORE      0             // PRO core

// ------------------------------------------------------------
// Tarea: heartbeat LED
// ------------------------------------------------------------
static void taskBlink(void *pvParameters) {
    (void)pvParameters;
    TickType_t lastWake = xTaskGetTickCount();

    for (;;) {
        digitalWrite(PIN_LED_HEARTBEAT, !digitalRead(PIN_LED_HEARTBEAT));
        vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(LED_BLINK_MS));
    }
}

// ------------------------------------------------------------
// Interfaz del módulo (init + start)
// ------------------------------------------------------------
static bool heartbeatInit(void) {
    // El pin ya fue configurado por sysResourcesInit(); si este
    // módulo usara un LED propio, aquí iría su pinMode().
    return true;
}

static void heartbeatStart(void) {
    xTaskCreatePinnedToCore(taskBlink, "TaskBlink",
                            TASK_BLINK_STACK, NULL,
                            TASK_BLINK_PRIO, NULL,
                            TASK_BLINK_CORE);
}

// ------------------------------------------------------------
// Auto-registro: prio 10 (diagnóstico temprano), no crítico
// ------------------------------------------------------------
REGISTER_MODULE("heartbeat", heartbeatInit, heartbeatStart, 10, false);
