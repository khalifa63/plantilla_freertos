// ============================================================
// sys_resources.h - Recursos compartidos de sistema
//
// Buses y primitivas que pertenecen al SISTEMA, no a un módulo:
//   - Bus I2C (Wire) + mutex de acceso
//   - Bus de EVENTOS entre módulos (cola FreeRTOS): permite que
//     un módulo (ej. button) notifique a otro (ej. display) sin
//     que se conozcan entre sí — clave del plug-and-play
//   - Error fatal con código visual en LED
// ============================================================
#ifndef SYS_RESOURCES_H
#define SYS_RESOURCES_H

#include <Arduino.h>

// ------------------------------------------------------------
// Eventos de sistema (agregar nuevos al final del enum)
// ------------------------------------------------------------
typedef enum : uint8_t {
    SYS_EVT_NONE = 0,
    // Agregar aqui los eventos del proyecto, por ejemplo:
    // SYS_EVT_BUTTON_SHORT,
    // SYS_EVT_GPS_FIX,
    // SYS_EVT_MOTION_DETECTED,
} SysEvent;

// Espera indefinida para sysEventReceive()
#define SYS_WAIT_FOREVER  0xFFFFFFFFUL

// Inicializa Wire (SDA/SCL de app_config.h), crea el mutex I2C,
// la cola de eventos y configura el LED de sistema.
// Llamar PRIMERO en setup(). Devuelve false si falla la creación.
bool sysResourcesInit(void);

// --- Bus I2C ---
bool i2cLock(void);
void i2cUnlock(void);

// --- Bus de eventos ---
// Publica un evento (no bloqueante). false si la cola está llena.
bool sysEventSend(SysEvent evt);
// Espera un evento hasta timeoutMs (o SYS_WAIT_FOREVER).
// true si llegó un evento, false si venció el timeout.
bool sysEventReceive(SysEvent *evt, uint32_t timeoutMs);

// --- Error fatal: log + parpadeo rápido en bucle. NO retorna ---
void sysFatalError(const char *msg);

#endif // SYS_RESOURCES_H
