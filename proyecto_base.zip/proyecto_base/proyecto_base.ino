// ============================================================
// proyecto_base.ino - Sketch principal GENÉRICO (NO SE MODIFICA)
// ESP32 | FreeRTOS | Arquitectura plug-and-play de módulos
//
// PROYECTO BASE VACÍO: punto de partida para cualquier proyecto.
// Incluye solo infraestructura + heartbeat (señal de vida).
// Para empezar un proyecto nuevo, ver README.md.
//
// Cada módulo de hardware es un .cpp en la raíz del sketch que
// se registra solo con REGISTER_MODULE. Este archivo únicamente
// orquesta:
//   1. Recursos de sistema (I2C + mutex + cola de eventos + LED)
//   2. Init de todos los módulos (orden por prioridad)
//   3. Arranque de las tareas FreeRTOS de cada módulo
//
// Estructura del proyecto (todos los archivos en la raíz):
//   proyecto_base.ino      -> este archivo (no se toca)
//   app_config.h           -> config de SISTEMA (buses, serial)
//   module_manager.h/.cpp  -> registro y ciclo de vida (no se toca)
//   sys_resources.h/.cpp   -> I2C, mutex, eventos, error fatal
//   heartbeat.cpp          -> módulo LED de vida (autocontenido)
//   modulo_plantilla.cpp   -> esqueleto para copiar por cada
//                             hardware nuevo (ver README.md)
// ============================================================
#include <Arduino.h>
#include "app_config.h"
#include "module_manager.h"
#include "sys_resources.h"

void setup() {
    Serial.begin(SERIAL_BAUD);
    delay(200);
    Serial.println(F("\n[BOOT] Proyecto base plug-and-play + FreeRTOS"));

    // 1. Recursos compartidos (deben existir antes que los módulos)
    if (!sysResourcesInit()) {
        sysFatalError("No se pudieron crear los recursos de sistema");
    }

    // 2. Init de módulos en orden de prioridad
    if (!modulesInitAll()) {
        sysFatalError("Fallo en init de modulo critico");
    }

    // 3. Lanzar tareas de los módulos inicializados
    modulesStartAll();

    Serial.println(F("[OK] Sistema en marcha"));
}

void loop() {
    vTaskDelete(NULL);   // Elimina la tarea loopTask de Arduino
}
