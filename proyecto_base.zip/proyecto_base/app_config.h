// ============================================================
// app_config.h - Configuración de SISTEMA (recursos compartidos)
//
// Regla de arquitectura plug-and-play:
//   - Aquí va SOLO lo compartido entre módulos (buses, serial,
//     límites del gestor de módulos).
//   - La configuración propia de cada módulo (pines, dirección,
//     periodos, stack/prioridad de su tarea) vive en el bloque
//     "CONFIG DEL MÓDULO" al inicio de su propio .cpp.
//   Así, agregar hardware nuevo NO requiere editar este archivo.
//
// Guard renombrado (APP_CONFIG_H) para no colisionar con
// Config.h de librerías o módulos de terceros.
// ============================================================
#ifndef APP_CONFIG_H
#define APP_CONFIG_H

// --- Bus I2C compartido ---
#define PIN_I2C_SDA          14
#define PIN_I2C_SCL          13
#define I2C_FREQ_HZ          400000UL   // 400 kHz fast mode
#define I2C_MUTEX_TIMEOUT_MS 100

// --- Serial ---
#define SERIAL_BAUD          115200

// --- Gestor de módulos ---
#define MAX_MODULES          16         // Capacidad del registro (array fijo, sin heap)

// --- LED de sistema (usado por sysFatalError) ---
#define PIN_LED_SYS          2

#endif // APP_CONFIG_H
