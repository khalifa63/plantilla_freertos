// ============================================================
// module_manager.cpp - Implementación del gestor de módulos
//
// - Registro en array fijo (sin heap, sin std::vector)
// - "Construct on first use": el array vive dentro de una
//   función para garantizar que existe cuando los constructores
//   estáticos de los módulos llaman a moduleRegister()
// - Init ordenado por prioridad (insertion sort, N<=16)
// ============================================================
#include "app_config.h"
#include "module_manager.h"

// ------------------------------------------------------------
// Almacenamiento del registro (privado)
// ------------------------------------------------------------
struct Registry {
    ModuleDesc list[MAX_MODULES];
    bool       initOk[MAX_MODULES];   // resultado del init de cada módulo
    uint8_t    count;
};

static Registry &reg(void) {
    // Local static: se construye en el primer uso, antes de
    // cualquier registro, sin depender del orden de enlazado.
    static Registry r = {};
    return r;
}

// ------------------------------------------------------------
// Auto-registro (llamado por constructores antes de setup)
// ------------------------------------------------------------
bool moduleRegister(const ModuleDesc &desc) {
    Registry &r = reg();
    if (r.count >= MAX_MODULES) {
        // Serial aún no existe en esta fase; el desborde se
        // reporta en modulesInitAll().
        return false;
    }
    r.list[r.count] = desc;
    r.initOk[r.count] = false;
    r.count++;
    return true;
}

// ------------------------------------------------------------
// Orden por prioridad (insertion sort, estable, N pequeño)
// ------------------------------------------------------------
static void sortByPriority(Registry &r) {
    for (uint8_t i = 1; i < r.count; i++) {
        ModuleDesc key = r.list[i];
        int8_t j = (int8_t)i - 1;
        while (j >= 0 && r.list[j].priority > key.priority) {
            r.list[j + 1] = r.list[j];
            j--;
        }
        r.list[j + 1] = key;
    }
}

// ------------------------------------------------------------
// Init de todos los módulos
// ------------------------------------------------------------
bool modulesInitAll(void) {
    Registry &r = reg();
    sortByPriority(r);

    Serial.printf("[MODULES] %u modulo(s) registrados (max %u)\n",
                  r.count, (unsigned)MAX_MODULES);

    bool systemOk = true;

    for (uint8_t i = 0; i < r.count; i++) {
        ModuleDesc &m = r.list[i];
        Serial.printf("[MODULES] init '%s' (prio %u)... ", m.name, m.priority);

        bool ok = (m.init != NULL) ? m.init() : true;
        r.initOk[i] = ok;

        if (ok) {
            Serial.println(F("OK"));
        } else if (m.critical) {
            Serial.printf("[FATAL] modulo critico '%s' fallo en init\n", m.name);
            systemOk = false;
        } else {
            Serial.printf("[WARN] modulo '%s' fallo en init; el sistema continua\n",
                          m.name);
        }
    }
    return systemOk;
}

// ------------------------------------------------------------
// Arranque de tareas (solo módulos con init exitoso)
// ------------------------------------------------------------
void modulesStartAll(void) {
    Registry &r = reg();
    for (uint8_t i = 0; i < r.count; i++) {
        if (r.initOk[i] && r.list[i].start != NULL) {
            r.list[i].start();
            Serial.printf("[MODULES] tarea de '%s' lanzada\n", r.list[i].name);
        }
    }
}
