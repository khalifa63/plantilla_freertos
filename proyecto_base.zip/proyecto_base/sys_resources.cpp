// ============================================================
// sys_resources.cpp - Implementación de recursos de sistema
// ============================================================
#include <Wire.h>
#include "app_config.h"
#include "sys_resources.h"

// ------------------------------------------------------------
// Estado privado
// ------------------------------------------------------------
static SemaphoreHandle_t i2cMutex   = NULL;
static QueueHandle_t     eventQueue = NULL;

#define EVENT_QUEUE_LEN  8   // Eventos en vuelo (uint8_t c/u)

// ------------------------------------------------------------
// API pública
// ------------------------------------------------------------
bool sysResourcesInit(void) {
    pinMode(PIN_LED_SYS, OUTPUT);
    digitalWrite(PIN_LED_SYS, LOW);

    Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_FREQ_HZ);

    i2cMutex   = xSemaphoreCreateMutex();
    eventQueue = xQueueCreate(EVENT_QUEUE_LEN, sizeof(SysEvent));

    return (i2cMutex != NULL) && (eventQueue != NULL);
}

// --- Bus I2C ---
bool i2cLock(void) {
    if (i2cMutex == NULL) return false;
    return xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(I2C_MUTEX_TIMEOUT_MS)) == pdTRUE;
}

void i2cUnlock(void) {
    if (i2cMutex != NULL) {
        xSemaphoreGive(i2cMutex);
    }
}

// --- Bus de eventos ---
bool sysEventSend(SysEvent evt) {
    if (eventQueue == NULL) return false;
    return xQueueSend(eventQueue, &evt, 0) == pdTRUE;   // No bloqueante
}

bool sysEventReceive(SysEvent *evt, uint32_t timeoutMs) {
    if (eventQueue == NULL || evt == NULL) return false;
    TickType_t ticks = (timeoutMs == SYS_WAIT_FOREVER)
                           ? portMAX_DELAY
                           : pdMS_TO_TICKS(timeoutMs);
    return xQueueReceive(eventQueue, evt, ticks) == pdTRUE;
}

// --- Error fatal ---
void sysFatalError(const char *msg) {
    Serial.printf("[FATAL] %s\n", msg);
    for (;;) {
        digitalWrite(PIN_LED_SYS, !digitalRead(PIN_LED_SYS));
        delay(100);
    }
}
