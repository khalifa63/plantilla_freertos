// ============================================================
// modulo_plantilla.cpp - ESQUELETO DE MÓDULO (copiar y renombrar)
//
// CÓMO USAR:
//   1. Copiar este archivo como  mi_hardware.cpp
//   2. Buscar todos los  TODO:  y completarlos
//   3. Compilar. Nada más se modifica en el proyecto.
//
// Este archivo COMPILA tal cual (módulo no-op que solo loguea),
// lo que sirve como prueba del gestor: en el boot debe aparecer
//   [MODULES] init 'plantilla' (prio 200)... OK
// Cuando el proyecto tenga módulos reales, puede borrarse.
//
// REGLAS DEL MÓDULO (resumen de la plantilla de prompt):
//   - Todo el estado en static (privado del archivo)
//   - NO definir setup(), loop() ni variables globales no-static
//   - Config propia en el bloque CONFIG DEL MÓDULO, con #define
//   - Bus I2C SIEMPRE entre i2cLock()/i2cUnlock()
//   - Comunicación con otros módulos via sysEventSend/Receive
//   - char[] + snprintf, nunca String en alta frecuencia
//   - vTaskDelayUntil para periodos exactos
// ============================================================
#include "app_config.h"
#include "module_manager.h"
#include "sys_resources.h"
// TODO: includes de librerías del hardware (ej. <Adafruit_XXX.h>)

// ------------------------------------------------------------
// CONFIG DEL MÓDULO
// TODO: pines, direcciones, periodos y parámetros de la tarea
// ------------------------------------------------------------
// #define PIN_MI_SENSOR        XX
// #define MI_SENSOR_ADDR       0xNN     // si es I2C
#define MODULO_PERIODO_MS       1000
#define TASK_MODULO_STACK       2048     // subir a 4096 si usa libs pesadas
#define TASK_MODULO_PRIO        1        // 1-3 tipico (mayor = mas urgente)
#define TASK_MODULO_CORE        0        // 0=PRO, 1=APP

// ------------------------------------------------------------
// Estado privado del módulo (todo static)
// TODO: objetos de librería, buffers, contadores
// ------------------------------------------------------------
// static Adafruit_XXX sensor;

// ------------------------------------------------------------
// Tarea principal del módulo
// ------------------------------------------------------------
static void taskModulo(void *pvParameters) {
    (void)pvParameters;
    TickType_t lastWake = xTaskGetTickCount();

    for (;;) {
        // TODO: trabajo periodico del modulo. Ejemplos:
        //
        // Lectura I2C protegida:
        //   if (i2cLock()) {
        //       sensor.read(...);
        //       i2cUnlock();
        //   }
        //
        // Publicar un evento para otros modulos:
        //   sysEventSend(SYS_EVT_MI_EVENTO);   // (agregarlo al enum
        //                                      //  en sys_resources.h)
        //
        // Esperar eventos en lugar de periodo fijo:
        //   SysEvent evt;
        //   if (sysEventReceive(&evt, MODULO_PERIODO_MS)) { ... }

        vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(MODULO_PERIODO_MS));
    }
}

// ------------------------------------------------------------
// Init: configurar pines y verificar que el hardware responde.
// Devolver false si el hardware no contesta.
// ------------------------------------------------------------
static bool moduloInit(void) {
    // TODO: pinMode(...), probe del dispositivo, init de libreria.
    // Ejemplo I2C:
    //   if (i2cLock()) {
    //       bool ok = sensor.begin(MI_SENSOR_ADDR);
    //       i2cUnlock();
    //       return ok;
    //   }
    //   return false;
    return true;   // No-op: siempre OK
}

// ------------------------------------------------------------
// Start: lanzar la(s) tarea(s) del módulo
// ------------------------------------------------------------
static void moduloStart(void) {
    xTaskCreatePinnedToCore(taskModulo, "TaskModulo",   // TODO: renombrar
                            TASK_MODULO_STACK, NULL,
                            TASK_MODULO_PRIO, NULL,
                            TASK_MODULO_CORE);
}

// ------------------------------------------------------------
// Auto-registro
// TODO: nombre, prioridad y criticidad del módulo
//   priority: 10=diagnostico, 50=sensores/entradas, 100=salidas/UI,
//             200=opcionales
//   critical: true -> si init falla, el sistema se detiene
// ------------------------------------------------------------
REGISTER_MODULE("plantilla", moduloInit, moduloStart, 200, false);
