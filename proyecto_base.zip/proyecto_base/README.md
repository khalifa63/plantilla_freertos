# Proyecto Base — ESP32 + FreeRTOS plug-and-play

Plantilla vacía para arrancar cualquier proyecto de hardware. Incluye solo
infraestructura + un módulo heartbeat (LED GPIO2) como señal de vida.

## Empezar un proyecto nuevo

1. Copiar la carpeta completa y renombrarla, ej. `mi_proyecto/`
2. Renombrar `proyecto_base.ino` → `mi_proyecto.ino`
   (Arduino IDE exige que el `.ino` se llame igual que la carpeta)
3. Abrir en Arduino IDE, compilar y subir. Verificar en el monitor
   serial (115200) que aparece el boot y el LED de GPIO2 parpadea:

   ```
   [BOOT] Proyecto base plug-and-play + FreeRTOS
   [MODULES] 2 modulo(s) registrados (max 16)
   [MODULES] init 'heartbeat' (prio 10)... OK
   [MODULES] init 'plantilla' (prio 200)... OK
   [OK] Sistema en marcha
   ```

## Agregar hardware nuevo

1. Copiar `modulo_plantilla.cpp` → `mi_hardware.cpp` (en la raíz del sketch)
2. Completar los `TODO:` (config, init, tarea, REGISTER_MODULE)
3. **Cerrar y reabrir el sketch** en Arduino IDE (no detecta archivos
   nuevos con el proyecto abierto) y compilar

No se modifica ningún otro archivo. Para quitar hardware, borrar su `.cpp`.

## Qué archivo se toca y cuándo

| Archivo | Se modifica cuando... |
|---|---|
| `mi_proyecto.ino` | NUNCA |
| `module_manager.h/.cpp` | NUNCA |
| `app_config.h` | Cambian pines del bus I2C, baud rate o MAX_MODULES |
| `sys_resources.h` | Se agrega un evento nuevo al enum `SysEvent` |
| `sys_resources.cpp` | Se agrega otro bus de sistema (SPI, UART compartido) |
| `modulo_xxx.cpp` | Todo lo demás: cada hardware vive en su archivo |

## Reglas de los módulos

- Todo el estado en `static` (privado del archivo). NO definir `setup()`,
  `loop()` ni globales no-static — eso causa `multiple definition` del linker.
- Config propia (pines, periodos, stack) en el bloque `CONFIG DEL MÓDULO`
  del propio `.cpp`, con `#define`.
- Acceso a I2C SIEMPRE entre `i2cLock()` / `i2cUnlock()`.
- Comunicación entre módulos por el bus de eventos
  (`sysEventSend` / `sysEventReceive`), nunca por globales compartidas.
- `char[]` + `snprintf`, nunca `String` en estructuras de alta frecuencia.
- `vTaskDelayUntil` para periodos exactos.
- Prioridades de registro: 10=diagnóstico, 50=sensores/entradas,
  100=salidas/UI, 200=opcionales. `critical=true` solo si el sistema no
  puede operar sin ese hardware.

## Convenciones de nombres (evitar colisiones)

- El config del proyecto es `app_config.h` con guard `APP_CONFIG_H`.
  Nunca crear archivos llamados `config.h` ni reutilizar el guard
  `CONFIG_H` (colisiona con librerías de terceros).
- Guard de cada header nuevo: `NOMBRE_ARCHIVO_H` único.

## Solución de problemas frecuentes

- **`multiple definition of ...`**: hay dos archivos con el mismo código
  o un módulo definió `setup()`/`loop()`/globales no-static.
- **"No changed sectors found" al subir**: el binario no cambió — el
  archivo nuevo no entró al build. Cerrar y reabrir el sketch.
- **Monitor serial vacío**: los logs son solo de arranque. Con el
  monitor abierto a 115200, presionar el botón EN de la placa.
- **Módulo I2C no responde**: verificar dirección (escáner I2C),
  cableado SDA/SCL y que el init esté entre `i2cLock()`/`i2cUnlock()`.
